#include "Core\Spectrum.h"
















